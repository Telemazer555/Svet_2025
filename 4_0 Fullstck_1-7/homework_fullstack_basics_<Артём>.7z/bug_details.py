data_types = { "id": '1',
               "Название": '2',
                "Статус": '3'
               }
print(data_types)
d = input("Введика брат новый статус: ")
a = data_types['Статус'] = d
print(data_types)